# you just need to do 2 steps:

-Go to the terminal and cd / to the Admin-UI directory
-npm install
-npm start
