import "./App.css";
import Admin from "./components/AdminUI";
function App() {
  return <Admin />;
}

export default App;
